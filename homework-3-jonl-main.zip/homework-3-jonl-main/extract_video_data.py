"""
This script will process data from transcripts thumbnails, 
and videos
"""

#%% imports

import os
import webvtt
import json
import pandas as pd

#%% functions

def clean_transcript(captions):
    """
    This function takes a webvtt list of captions
    and converts them to a single string of text
    """

    full_text = ''
    for caption in captions:
        caption.text = caption.text.split('\n')[-1]
        full_text += caption.text

    return full_text

def detect_faces():
    pass

def find_json_files(data_dir):
    """
    This function will find all of the .json files
    in the data_dir.
    """

    # list the files in the data_dir
    file_list = os.listdir(data_dir)

    # use a loop to check file names 
    json_files = []
    for file in file_list:
        if file.endswith('.info.json'):
            json_files.append(file)

    # return the list
    return json_files

def get_video_metadata(data_dir, filename):
    """
    This function will load a json file and get 
    the relevant metadata. It will return the data
    in a dictionary. 
    """

    with open(f'{data_dir}/{filename}') as f:
        data = json.load(f)

    # get json data
    video_info = {}
    video_info['video_id'] = data['id']
    video_info['live_status'] = data['live_status']
    video_info['comment_count'] = data['comment_count']
    video_info['like_count'] = data['like_count']
    print(f'get_video_metadata: {video_info}')

    return video_info

#%% main
if __name__=='__main__':
    transcript_folder = 'data/transcripts/'

    # video ids from transcript folder
    transcript_files = os.listdir(transcript_folder)
    video_ids = [file.split('.en.vtt')[0] for file in transcript_files]

    # load transcripts for each video id
    for video_id in video_ids:
        # load transcript
        captions = webvtt.read(f'{transcript_folder}{video_id}.en.vtt')
        print(f'Caption 0: {captions[0]}')
        print(f'Caption 0 text: {captions[0].text}')

        text = clean_transcript(captions)
        print(text)
    # %%  write transcript to txt file
    for video_id in video_ids:
        with open(f'{transcript_folder}{video_ids}.txt', 'w') as f:
            captions = webvtt.read(f'{transcript_folder}{video_id}.en.vtt')
            text = clean_transcript(captions)
            f.write(text)


  # %% find the json files
    data_dir = 'data/videos'
    json_files = find_json_files(data_dir)

    # %% process json files

    json_data = []
    for file in json_files:
        json_data.append(get_video_metadata(data_dir, file))

    # %% create and save a dataframe
metadata_df = pd.DataFrame(json_data)

    # %% save it to a CSV file
metadata_df.to_csv(f'{data_dir}/metadata.csv', index=False)
