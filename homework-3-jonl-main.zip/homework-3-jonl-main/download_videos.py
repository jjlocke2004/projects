"""
This script will select videos from a 
pre-made list of video IDs (CNBC video metadata).

It will download the videos, the transcripts,  
the highest-quality thumbnail, and video-specific
metadata. 
"""

#%% imports

import os
import yt_dlp
import ffmpeg
import pandas as pd


#%% options

# place to save videos
video_folder = 'data/videos/'
transcript_folder = 'data/transcripts/'
thumbnail_folder = 'data/thumbnails/'

# yt-dlp options
vid_opts = {
    'format': 'bestvideo+bestaudio/best',
	'outtmpl': f'{video_folder}%(id)s.%(ext)s',
	'writeinfojson': True,
}
thumb_opts = {
    'format': 'best',
    'outtmpl': f'{thumbnail_folder}%(id)s.%(ext)s',
    'writeinfojson': False,
}

transcript_opts = {
	'skip_download': True,
	'writeautomaticsub': True,
	'subtitleslangs': ['en'],
	'subtitlesformat': 'vtt',
	'outtmpl': f'{transcript_folder}%(id)s.%(ext)s',
	'writeinfojson': False,
}

#%% functions

def get_video_ids():
    metadata_file = 'data/metadata.csv'
    df = pd.read_csv(metadata_file)
    filtered_df = df[df['title'].str.contains('CEO')]
    video_ids = filtered_df['video_id'].tolist()
    return video_ids

def get_transcripts(video_id):
    """
    This function downloads the transcript for 
    the given video_id.
    """
    ts_ydl = yt_dlp.YoutubeDL(transcript_opts)
    ts_ydl.download([video_id])

def get_thumbnails(video_id):
    """
    This function downloads the thumbnail for
    the given video_id.
    """
    thumb_ydl = yt_dlp.YoutubeDL(thumb_opts)
    thumb_ydl.download([video_id])

def download_video(video_id):
    """
    This function uses the yt-dlp package to download
    the video with the given video_id.
    """
    vid_ydl = yt_dlp.YoutubeDL(vid_opts)
    vid_ydl.download([video_id])

    

#%% main

if __name__ == '__main__':

    # place to save data
    thumbnail_folder = 'data/thumbnails/'

    # check for the folder, if it is not there create it
    if not os.path.exists(thumbnail_folder):
        os.makedirs(thumbnail_folder)

    video_ids = get_video_ids()[:100]
    for video_id in video_ids:
        # check if the video has already been downloaded
        if os.path.exists(f'{video_folder}{video_id}.webm'):
            print(f'Already downloaded video {video_id}. Skipping...')
        else:
            print(f'Downloading video {video_id}')
            download_video(video_id)

# %% Convert files to vtt
# Convert files to vtt
for file in os.listdir(video_folder):
    if file.endswith('.info.json'):
        video_id = file.split('.')[0]
        transcript_opts['outtmpl'] = f'{transcript_folder}{video_id}'
        get_transcripts(video_id)
# %% 
