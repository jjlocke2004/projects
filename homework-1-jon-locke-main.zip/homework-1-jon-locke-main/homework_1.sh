#!/bin/bash

# Read addresses from the text file
addresses=($(shuf -n 3 ping_addresses))

# Log file path
log_file="ping_script_log.txt"

# Function to send email
send_email() {
    local subject="Ping Failure"
    local body="Ping Failure"
    echo "$body" | mail -s "$subject" kali@kali
}

# Loop through addresses and ping
for address in "${addresses[@]}"; do
    ping_output=$(ping -c 5 "$address")

    # Parse ping output
    packet_loss=$(echo "$ping_output" | awk '/packet loss/ {print $6}' | cut -d "%" -f 1)
    if [[ -z "$packet_loss" ]]; then
        packet_loss="100"
    fi

    # Check ping status
    if [[ "$packet_loss" -eq 100 ]]; then
        # Ping not responding or missing packets
        log_message="Ping to $address failed. Packet loss: $packet_loss%"
        echo "$(date): $log_message" >> "$log_file"
        send_email "Ping Failure" "$log_message"
    else
        # Device is normal
        log_message="Ping to $address successful. Packet loss: $packet_loss%"
        echo "$(date): $log_message" >> "$log_file"
    fi
done
